namespace Cultiway.Core;

public class AnimControllerMeta
{
    public float frame_interval;
    public bool  loop;
}