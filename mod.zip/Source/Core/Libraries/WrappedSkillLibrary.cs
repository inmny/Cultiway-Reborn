namespace Cultiway.Core.Libraries;

public class WrappedSkillLibrary : AssetLibrary<WrappedSkillAsset>
{
}