using Cultiway.Abstract;

namespace Cultiway.Core.Libraries;

public class StatusEffectLibrary : DynamicAssetLibrary<StatusEffectAsset>
{
    
}