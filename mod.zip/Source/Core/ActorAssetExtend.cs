namespace Cultiway.Core;

public class ActorAssetExtend
{
    /// <summary>
    ///     是否必然有灵根
    /// </summary>
    public bool must_have_element_root;
}