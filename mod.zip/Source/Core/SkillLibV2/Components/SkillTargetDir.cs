using Friflo.Engine.ECS;
using UnityEngine;

namespace Cultiway.Core.SkillLibV2.Components;

public struct SkillTargetDir : IComponent
{
    public Vector3 v3;
}