using Friflo.Engine.ECS;

namespace Cultiway.Core.SkillLibV2.Components;

public struct SkillStrength : IComponent
{
    public float value;
}