using Friflo.Engine.ECS;

namespace Cultiway.Core.SkillLibV2.Components;

public struct Radius : IComponent
{
    public float Value;
}