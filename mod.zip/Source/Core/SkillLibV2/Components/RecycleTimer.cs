using Friflo.Engine.ECS;

namespace Cultiway.Core.SkillLibV2.Components;

public struct RecycleTimer : IComponent
{
    public float value;
}