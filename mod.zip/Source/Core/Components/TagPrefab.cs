using Friflo.Engine.ECS;

namespace Cultiway.Core.Components;

public struct TagPrefab : ITag
{
}