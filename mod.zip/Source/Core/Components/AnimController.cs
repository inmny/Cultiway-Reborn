using Cultiway.Core.SkillLibV2;
using Friflo.Engine.ECS;
using Friflo.Json.Fliox;

namespace Cultiway.Core.Components;

public struct AnimController : IComponent
{
    [Ignore]
    public AnimControllerMeta meta;
}