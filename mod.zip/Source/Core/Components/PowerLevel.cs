using Friflo.Engine.ECS;

namespace Cultiway.Core.Components;

public struct PowerLevel : IComponent
{
    public float value;
}