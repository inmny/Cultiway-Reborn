using Friflo.Engine.ECS;

namespace Cultiway.Core.Components;

public struct TagReadyRecycle : ITag
{
}