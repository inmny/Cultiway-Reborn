using Friflo.Engine.ECS;

namespace Cultiway.Core.Components;

public struct StatusStatsMultiplier : IComponent
{
    public float Value;
}