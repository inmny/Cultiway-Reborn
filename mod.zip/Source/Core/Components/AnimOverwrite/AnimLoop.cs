using Friflo.Engine.ECS;

namespace Cultiway.Core.Components.AnimOverwrite;

public struct AnimLoop : IComponent
{
    public bool value;
}