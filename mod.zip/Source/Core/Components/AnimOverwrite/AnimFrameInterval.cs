using Friflo.Engine.ECS;

namespace Cultiway.Core.Components.AnimOverwrite;

public struct AnimFrameInterval : IComponent
{
    public float value;
}