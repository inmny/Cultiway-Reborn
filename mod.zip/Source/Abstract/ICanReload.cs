namespace Cultiway.Abstract;

public interface ICanReload
{
    public void OnReload();
}