namespace Cultiway.Abstract;

public interface ICanCopy
{
}