namespace Cultiway.Const;

public static class DamageCalcHyperParameters
{
    public const float ArmorEffectDecay  = 100;
    public const float MasterEffectDecay = 100;
    public const float PowerBase = 100;
}