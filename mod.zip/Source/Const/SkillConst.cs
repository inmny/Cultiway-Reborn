namespace Cultiway.Const;

public static class SkillConst
{
    public const float recycle_time = 60;
}