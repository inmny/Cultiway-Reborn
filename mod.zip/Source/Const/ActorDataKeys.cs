// ReSharper disable InconsistentNaming

namespace Cultiway.Const;

public static class ActorDataKeys
{
    public const string EntityId_Int = "cw_entity_id";
}