using UnityEngine;

namespace Cultiway.Const;

public static class UIColors
{
    public static readonly Color BackgroundTextColor = new(1, 0.607f, 0.110f, 0.180f);
}