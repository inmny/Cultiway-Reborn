namespace Cultiway.Const;

public static class SkillEnhanceSources
{
    public const string SmallUpgradeFailed = "SmallUpgradeFailed";
    public const string LargeUpgradeFailed = "LargeUpgradeFailed";
    public const string SmallUpgradeSuccess = "SmallUpgradeSuccess";
    public const string LargeUpgradeSuccess = "LargeUpgradeSuccess";
}