using Friflo.Engine.ECS;

namespace Cultiway.Content.Components;

public struct TagElixirStatusGain : ITag
{
}