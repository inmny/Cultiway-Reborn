namespace Cultiway.Content.Libraries;

public class CultibookBaseLibrary : AssetLibrary<CultibookBaseAsset>
{
    
}