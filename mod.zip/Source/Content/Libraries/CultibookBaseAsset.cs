namespace Cultiway.Content.Libraries;

public class CultibookBaseAsset : Asset
{
    
}