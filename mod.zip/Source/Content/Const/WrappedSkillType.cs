namespace Cultiway.Content.Const;

public enum WrappedSkillType
{
    Attack
}