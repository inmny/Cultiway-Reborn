namespace Cultiway.Content.Const;

public static class XianLevels
{
    public const int XianBase = 1;
    public const int Jindan = 2;
    public const int Yuanying = 3;
}