namespace Cultiway.LocaleKeys.UI;

public class Locale : LocalComponent
{
    public Window.Locale Window;
}